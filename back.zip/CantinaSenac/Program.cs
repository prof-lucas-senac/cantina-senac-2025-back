new AlunoControler().Adicionar(new Aluno()
{
    Id = 1,
    Email = "aluno@senac.br",
    Senha = "aluno"
});

LoginView.Exibir();

