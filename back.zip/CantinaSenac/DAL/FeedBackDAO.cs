public class FeedBackDAO

{
    List<Postagem> comentarios = new List<Postagem>();
    public void AdicionarComentario(Comentario comentario)
    {
        comentarios.Add(comentario);

    }

    public List<Comentario> ExibirTodosComentarios(List<Comentario> comentarios)
    {
        return comentarios;
    }

}