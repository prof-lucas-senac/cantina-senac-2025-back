public class Administrador : Usuario
{
    

    public override void ComentarFeedback()
    {
        throw new NotImplementedException();
    }

    public override void Logar()
    {
        throw new NotImplementedException();
    }

    public override void PublicarFeedback()
    {
        throw new NotImplementedException();
    }

    public void Suspender()
    {

    }

    public void Deletar()
    {

    }

    public void ListarTodos()
    {

    }

    public void CadastrarCurso()
    {

    }

    public void AtualizarCurso()
    {

    }

    public void DeletarCurso()
    {
        
    }
}