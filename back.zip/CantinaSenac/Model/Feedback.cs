public class Feedback : Postagem
{

}