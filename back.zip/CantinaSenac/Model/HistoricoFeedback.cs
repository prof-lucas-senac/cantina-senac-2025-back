public class HistoricoFeedBack
{
    public DateTime DataPublicacao { get; set; }
    public Postagem postagem { get; set; }
    public Usuario usuario { get; set; }

}