public class Curso
{
    public int IdCurso { get; set; }
    public string Nome { get; set; }
    public DateTime DataInicio { get; set; }
    public DateTime DataFinal { get; set; }
    public string Descricao { get; set; }

    public void ApresentarCurso()
    {
        
    }
}