static class FeedbacksViews
{
    public static void Exibir()
    {
        Console.WriteLine($"Tela de Feedback.");
        Console.Write($"Digite seu Feedback:");
        string feedbackUsuario = Console.ReadLine();
        Postagem postagem = new Postagem();
        postagem.ExibirTodosComentarios();

      
    }
}