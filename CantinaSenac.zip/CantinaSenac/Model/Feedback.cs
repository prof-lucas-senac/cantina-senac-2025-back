class Feedback : Postagem
{
    
}